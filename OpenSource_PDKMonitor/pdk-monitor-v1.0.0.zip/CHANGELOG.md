# Changelog — CORNERSTONE Open Platform PDK Monitor

All notable changes to this project will be documented in this file. The
format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/).

## [1.0.0] — 2026-05-26

The official first public release of the CORNERSTONE Open Platform
PDK Monitor. Authored by **Emre Kaplan** during a focused 25-day
beta from 1 May 2026 → 26 May 2026.

### Architecture

- **Single-file HTML dashboard.** Open `pdk-monitor.html` in any
  modern browser — no install, no server, no build step. All state
  lives in the browser's IndexedDB + `localStorage`; sharing happens
  through GitHub.

- **Real-files architecture.** When a user-admin publishes their
  slice, every uploaded item (CSV, GDS, S-matrix file, document,
  script) is written as a SEPARATE real file in the repo under
  `users/<id>/<section>/<bb>/<filename>`. The `dashboard.json`
  carries only metadata + `repoPath` references. Pool members
  hydrate the real bytes on fetch.

- **Three-tier role model.**
  - **Admin** — full control, owns the main `dashboard.json`.
  - **User-admin** — owns their own `users/<id>/` folder; can
    publish, prune, and wipe it without ever touching the main
    `dashboard.json`.
  - **Read-only** — view, search, run scripts, download.

### Features

#### Platforms & BBs

- Multi-platform tabs (SOI 220, TFLN 300, SiN 200/300, etc.) with
  per-platform BB libraries grouped by BB type.
- Per-BB tabs: Overview, Layout (GDS), S-matrix, Tests, Fab,
  Scripts, Documents.
- Inline GDS preview rendered from raw GDS bytes; layer/datatype
  metadata exposed in the Layout tab.
- Custom sketch upload (PNG / SVG / JPG) per BB, with augmented
  procedural sketches as the default (material gradients, I/O
  arrows, dimension lines).
- Per-platform BB-type shortlist on the column head — filter
  visible BBs by type.

#### S-matrix / Tests / Fabrication

- Parsers for CSV / TSV / XLSX / S1P–S8P touchstone / DAT / JSON /
  TXT — every file type plots as `📊 N pts · Y traces`.
- Canonical "Files" folder per BB with the stable id
  (`sg_files` / `tg_files` / `ft_files`); on-load + post-merge
  consolidator collapses duplicate folders across version
  histories.
- Folder-name routing — a GitHub folder named `tests/` /
  `sparams/` / `fab/` auto-routes contents to the matching BB
  section.
- Per-section GitHub fetch with smart filtering (smatrix mode
  skips READMEs, licences, configs; depth-5 walker for nested
  layouts).

#### GDS Layers

- Top-level Layers list: name, layer/datatype, description, colour.
- Hover popover with full description.
- Sortable by layer number; filterable by BB type via the
  Manage-list dropdown.

#### Distribution & multi-user pool

- **Shared repositories** — configure multiple sources, each with
  enable / disable.
- **📥 Fetch all enabled sources** — pulls main `dashboard.json` +
  auto-walks every plausible `users/` location (sibling, parent,
  repo-root, `OpenSource_PDKMonitor/users`).
- **🔍 Discover user slices** — explicit walker, multi-pick UI.
- **🪪 Fetch my slice** *(user-admin)* — pulls + bootstraps the
  signed-in user's own slice.
- **📚 Fetch user repos** *(advanced)* — one-click pool assembly,
  walks every `users/<id>/` across every enabled source.
- **Merge into my dashboard** — additive, never overwrites local
  changes.
- **🔁 Replace whole dashboard** *(danger)* — wipes local copy +
  uses merged remote. Always downloads a Backup `.json` first.
- **📤 Publish as Pull Request** / **⚡ Direct commit** — both
  routes available; user-admin direct commits auto-route to their
  `users/<id>/dashboard.json` and externalize binaries to real
  files in their folder.
- **🌱 Seed user folders from sign-in list** *(admin)* — creates
  `users/<id>/dashboard.json` for every entry in the password list.
- **🗑 Wipe my repo folder** *(user-admin, danger)* — nuclear
  delete of every file under `users/<id>/`; local model untouched.

#### User-admin write-back mirror

- Every ⚡ Direct commit externalizes new / changed binary items as
  real files, then prunes orphan files that are no longer
  referenced — so the repo folder mirrors the local model
  exactly.
- Idempotent — re-publishing only uploads new / changed items.

#### Robustness

- Three-tier publish fallback: PUT → retry on conflict → git tree
  API. Survives BadObjectState / 422 / 500.
- Eight retries with exponential + jittered backoff.
- Heavy-binary strip (256 KB documents, 4 MB datasets, 2 MB parsed
  arrays) keeps `dashboard.json` under the GitHub contents API
  cap when binaries can't be externalized.
- Multi-location user folder discovery (sibling, parent + /users,
  repo-root, `OpenSource_PDKMonitor/users`).
- Hydrate re-parses CSV / XLSX / touchstone on fetch so adopters
  see real parsed data, not inert raw text.

#### Duplicate resolver

- Same-name BBs / groups / tabs collapsed via cluster picker.
- Cross-platform BB clusters with user-selectable keeper +
  "Merge into selected keeper" / "Attach as variants of keeper"
  actions.
- On-load consolidator runs automatically — folders with the same
  normalised name fold into one canonical folder per BB.

#### Scripts

- Inline Python runner (Pyodide-based) with sandbox.
- `data` / `tests` / `bb` globals expose parsed data.
- **💻 Run locally…** packs script + every BB file into a folder
  with VS Code / PyCharm / Sublime deeplinks.

#### Security

- Admin password lives in `localStorage` only — never published.
- User-admin sign-ins (guestPasswords) publish as
  `_distributedSecurity` so adopters get the sign-in list.
- GitHub token lives in `localStorage`; the dashboard never bundles
  it.

### Limits

- Per-file upload cap: 50 MB (smaller of GitHub contents API limit
  and browser memory).
- Total project size: ~10 GB across all files for the in-browser
  IndexedDB store.
- Recommended pool size: up to ~20 user-admin slices per main
  repository; pool assembly scales O(N) in API calls.

### What's in the bundle

```
pdk-monitor.html
pdk-monitor-v1_0_0.html        ← versioned copy for GitHub direct upload
dashboard-v1_0_0.json          ← canonical starter dashboard JSON
PDK-Monitor-User-Manual.pdf
PDK-Monitor-User-Manual.docx
TERMS.md
LICENSE-TAPR.txt
CHANGELOG.md
RELEASE_NOTES.md
README.md
```

### Licence

Hardware content: **TAPR Open Hardware License v1.0** (see
`LICENSE-TAPR.txt`).

### Credits

Authored by **Emre Kaplan** (a.emrekaplan@gmail.com) for the
CORNERSTONE Open Platform — the UK silicon-photonics rapid
prototyping foundry programme at the University of Southampton
(https://www.cornerstone.sotonfab.co.uk/).

The portal is open to everyone for further development.

---

## Development history (pre-1.0.0)

Daily-iteration log between the 1 May 2026 beta and the 26 May 2026
official release. Internal version numbers were used during this
period and are NOT part of the public versioning scheme — every
feature listed below is included in v1.0.0.

- Beta `b0.1` (01 May 2026) — initial single-page dashboard with
  platform list, BB list, basic file uploads.
- Platform import workflow + GDS parsing.
- GDS Layers list with hover popovers.
- Role-based access (admin / user-admin / read-only).
- Distribution panel (configure sources, fetch, merge, replace).
- Robust publish helper with PUT → retry → tree-API fallback.
- User-admin slice publishing into `users/<id>/dashboard.json`.
- Duplicate resolver (within-platform).
- Cross-platform duplicate resolver with variant attachment.
- Real-files architecture — externalize binaries, hydrate on fetch.
- Orphan file pruning on publish + 🗑 Wipe my repo folder button.
- Multi-location `users/` discovery (both single-file + directory
  modes).
- 📚 Fetch user repos one-click pool assembly.
- Empty S-matrix entries fix (hydrate re-parse + smatrix-only
  extension filter + depth-5 walker).
- On-load + post-merge duplicate folder consolidator.
