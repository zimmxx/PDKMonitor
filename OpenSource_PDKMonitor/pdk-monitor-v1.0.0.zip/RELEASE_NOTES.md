# Release notes — PDK Monitor v1.0.0

**Release date:** 26 May 2026
**Author:** Emre Kaplan
**Operator:** CORNERSTONE Open Platform
**Licence:** TAPR Open Hardware License v1.0

## Official public release

This is the first formal public release of the CORNERSTONE Open
Platform PDK Monitor. The dashboard has been through a focused
25-day beta from 1 May 2026 → 26 May 2026; every feature listed
below is included and tested.

## At a glance

A self-contained HTML dashboard for silicon-photonics PDK content
that you can open in any modern browser. No install, no server,
no build step. Tracks Building Blocks across multiple technology
platforms, stores GDS / S-matrix / test / fab files, runs Python
scripts against the data in-browser, and synchronises with a team
through GitHub.

## What's in the box

| File | What it is |
|---|---|
| `pdk-monitor.html` | The dashboard. Open in any modern browser. |
| `pdk-monitor-v1_0_0.html` | Versioned copy for direct upload to a GitHub release page. |
| `dashboard-v1_0_0.json` | Canonical starter dashboard — host alongside the HTML for fresh installs. |
| `PDK-Monitor-User-Manual.pdf` | Full user manual (PDF, printable). |
| `PDK-Monitor-User-Manual.docx` | Same manual as a Word document. |
| `TERMS.md` | Terms of use. |
| `LICENSE-TAPR.txt` | TAPR Open Hardware License v1.0. |
| `CHANGELOG.md` | Per-version change log. |
| `RELEASE_NOTES.md` | This file. |
| `README.md` | One-page overview + quick start. |

## Three roles, clean separation

| Role | Can | Cannot |
|---|---|---|
| **Read-only** | View, search, run scripts, download | Edit anything |
| **User-admin** | All Read-only + own their `users/<id>/` folder fully | Touch the main `dashboard.json` |
| **Admin** | Everything | n/a |

## Real-files architecture

Every uploaded binary item (CSV, GDS, S-matrix touchstone, document,
script) is written to the repo as a SEPARATE FILE under
`users/<id>/<section>/<bb-name>__<id-suffix>/<filename>`. The
`dashboard.json` itself stays small (metadata + `repoPath` only)
and pool members hydrate the real bytes on fetch.

### Add / remove / nuke

* **Add** — upload locally + ⚡ Direct commit → file appears in
  the repo.
* **Remove** — delete locally + ⚡ Direct commit → file is pruned
  from the repo on the same publish.
* **Nuke** — 🗑 Wipe my repo folder → every file under `users/<id>/`
  is deleted; local model untouched; next publish rebuilds.

The repo folder is a true write-back mirror of the user-admin's
local state.

## Multi-user pool — one click

Open *Distribution → Fetch & adopt* → click **📚 Fetch user repos**
in the *Multi-user pool sync (advanced)* drawer. The dashboard:

1. Walks every enabled source.
2. Tries every plausible `users/` location (sibling, parent +
   `/users`, repo-root `/users`, `OpenSource_PDKMonitor/users`).
3. For each `users/<id>/dashboard.json`, fetches the metadata AND
   downloads every real file the slice references.
4. Stages the lot for merge.

Click **Merge into my dashboard** and you have a complete
multi-user view of every contributor's work with their actual lab
data (S-matrix, test results, datasheets, scripts) integrated into
your local copy.

## Quick start

1. Download `pdk-monitor-v1.0.0.zip` from the release.
2. Open `pdk-monitor.html` in your browser.
3. Sign in: click the mode pill in the header, type the default
   admin password `CS2026_PDK_Design&Test` (change it from
   *Manage → Passwords* afterwards).
4. Pull a real PDK from GitHub:
   * Click *Edit* on a Technology Platform column.
   * Paste the platform's GitHub folder URL.
   * Save → click **⤓ Import platform**.
5. Configure a Shared repository in the Distribution panel,
   ⚡ Direct commit your work, and invite team members to
   fetch it.

## Limits

* Per-file upload: up to **50 MB** (GitHub contents API limit).
* Total project size: ~10 GB across all files in browser IndexedDB.
* Recommended pool size: up to ~20 user-admin slices per main repo.

## Compatibility

* Chrome / Edge / Firefox / Safari (latest stable + one).
* GitHub PAT with `repo` scope is recommended for private repos
  and to lift the 60 req/h public rate limit.

## Author

**Emre Kaplan** — a.emrekaplan@gmail.com

The portal is open to everyone for further development.
